Unzip the pretrained models archive file here to usethe models we provide!

Your own models will also be saved here under a randomly assigned ID.